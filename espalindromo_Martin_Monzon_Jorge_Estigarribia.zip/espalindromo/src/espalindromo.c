#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "funciones.h"

int main(void){
  menu();
  char *c = getText("output.txt");
  printf("%s",c);
  return 0;
}
char *getText(const char *file) {
	static char *text;
    text =  (char *)malloc(21);
    FILE * title;
    int c;
    int counter = 0;
    title = fopen(file, "r");

    while ((c = fgetc(title)) != EOF){
        if(counter % 20 == 0 && counter != 0) text = (char *)realloc(text, counter+50);
		text[counter] = c;
		counter++;
    }
	text[counter] = '\0';
	//printf("%s",text);
	fclose(title);
	return text;
}
void menu(void){
  FILE* outPut = fopen("output.txt","w+");
  char *str;
  char *fstr;
  int isPal;
  printf("Introduzca las palabras u oraciones para saber si son palindromas o no, escriba exit para el resultado.\n");
  do{
    str = introLinea(); 
    fstr = filtrarLinea(str);
    isPal = esPalindromo(fstr);
    if(strcmp(str,"exit")){
      if(isPal)
        fprintf(outPut,"%s es Palindromo.\n",str);
      else
        fprintf(outPut,"%s no es Palindromo.\n",str);
    }
  }while(strcmp(str,"exit"));
  fclose(outPut);
}

int esPalindromo(char *cadena){
  for(int i = 0,j = strlen(cadena)-1;i < strlen(cadena); i++,j--){
    //printf("i:%d j:%d\n",i,j);
    if(cadena[i] != cadena[j]){
      return 0;
    }
  }
  return 1;
}

char *filtrarLinea(char *cadena){
  int len = strlen(cadena);
  char *pcadena = (char *) malloc(len*sizeof(char));
  for(int i = 0;i <len;i++) pcadena[i] = 0;
  for(int i = 0,j=0;cadena[i];i++){
      if(cadena[i] != ' '){
        pcadena[j++] = cadena[i];
      }
  }
  return pcadena;
}

char *introLinea(void){
  char *input = (char*)malloc(1*sizeof(char));
  int i = 1;
  char string;
  do{
    string = getchar();
    input = (char*)realloc(input,i*sizeof(char));
    input[i-1] = tolower(string);
    i++;
  }while(string != '\n');
  input[i-2] = 0;
  return input;
}
