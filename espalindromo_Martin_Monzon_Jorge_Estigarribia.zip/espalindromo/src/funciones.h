char *getText(const char *file);
void tuMama();
void menu(void);
char *introLinea(void);
char *filtrarLinea(char *cadena);
int esPalindromo(char *cadena);